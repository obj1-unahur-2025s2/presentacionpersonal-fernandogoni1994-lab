![Logo UNAHUR](./UNAHUR.png)

# Programación con objetos I
## Presentación Personal
- Alumno de UNAHUR, actualmente me encuentro cursando el segundo año de la carrera con la misma motivación que con la cual empecé. Soy una persona organizada, con mucho respeto hacia las responsabilidades que me toca afrontar día a día. Soy compromiso, disciplina y entusiasmo, conceptos que trato de mantener en eje.
  Con respecto a mi historia con la carrera, desde hace años que estoy en búsqueda de algo relacionado a la informática y creo que por fin estoy perfilandome para donde quiero formar mi futuro profesional.
  Desde desarrollo de apps, páginas web y simples algoritmos a modo de ejercitación autodidacta, he recorrido y explorado distintos ámbitos relacionados a la Programación, sin embargo hay una sola cosa que me llama realmente la atención y esta es: Analisis de Datos.
Creo que el aprendizaje y el título que me va a dar la Tecnicatura Universitaria en Programación, me puede ayudar a perfilarme para ese territorio poco explorado por mi parte.


### Datos Personales
- Mi nombre es: Fernando Martín Goñi
- Vivo en Martín Coronado, Tres de Febrero, Buenos Aires

### Tips
- No se olviden de tomar agua.
- Siempre prioricen el confort de una buena silla al momento de sentarse a programar.
- Hagan actividad física, escuchen a su cuerpo.
- Acá van a tener un compañero responsable, firme y con ganas de colaborar para la ocasión que se presente.

